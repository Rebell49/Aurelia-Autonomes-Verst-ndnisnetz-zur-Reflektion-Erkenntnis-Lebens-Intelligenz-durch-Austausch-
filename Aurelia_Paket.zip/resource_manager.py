﻿class ResourceManager:
    def __init__(self):
        self.cpu_limit = 50
        self.ram_limit = 100_000_000

    def check_resources(self):
        pass
